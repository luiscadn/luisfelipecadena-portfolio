package org.example.demo;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;

public class OptionsController {

    @FXML
    private ToggleGroup graphToggleGroup;

    @FXML
    public void startGame() {
        RadioButton selectedRadioButton = (RadioButton) graphToggleGroup.getSelectedToggle();
        String toggleGroupValue = selectedRadioButton.getText();

        Graph graph;
        if ("Usar GraphList".equals(toggleGroupValue)) {
            graph = new GraphList();
        } else {
            graph = new GraphMatrix(400); // Ajusta el tamaño según sea necesario
        }

        GameController gameController = new GameController();
        gameController.setGraph(graph);
        gameController.startGame();

        // Cambiar a la vista del juego
        Main.changeScene("game-view.fxml");
    }

    @FXML
    public void showInstructions() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Instrucciones");
        alert.setHeaderText(null);
        alert.setContentText("Usa las teclas de flechas o WASD para mover la serpiente. Come tantas frutas como puedas y evita colisionar con las paredes o contigo mismo.");
        alert.showAndWait();
    }
}