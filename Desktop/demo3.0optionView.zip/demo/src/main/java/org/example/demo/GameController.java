package org.example.demo;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.Optional;

public class GameController {
    @FXML
    private GridPane gameGrid;

    @FXML
    private Label scoreLabel;

    @FXML
    private Label movesLabel;

    @FXML
    private Label lengthLabel;

    private Game game;
    private int score;

    private Graph graph;

    public void setGraph(Graph graph) {
        this.graph = graph;
    }

    @FXML
    public void initialize() {
        score = 0;
        updateScore(0);
        gameGrid.setFocusTraversable(true);
        gameGrid.setOnKeyPressed(this::handleKeyPress);
    }

    public void startGame() {
        if (graph == null) {
            graph = new GraphList();
        }

        game = new Game(graph);
        score = 0;
        updateScore(0);
        updateMoves(0);
        updateLength(1);
        drawGame();
        gameGrid.requestFocus();
    }

    public void exitGame() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Salir");
        alert.setHeaderText(null);
        alert.setContentText("¿Estás seguro de que deseas salir?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            System.exit(0);
        }
    }

    private void updateScore(int increment) {
        score += increment;
        scoreLabel.setText(String.valueOf(score));
    }

    private void updateMoves(int moves) {
        movesLabel.setText(String.valueOf(moves));
    }

    private void updateLength(int length) {
        lengthLabel.setText(String.valueOf(length));
    }

    private void drawGame() {
        gameGrid.getChildren().clear();
        int rows = 20;
        int cols = 20;
        int cellSize = 30;

        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                Rectangle cell = new Rectangle(cellSize, cellSize);
                cell.setFill(Color.web("#3c4049"));
                cell.setStroke(Color.web("#282c34"));
                gameGrid.add(cell, col, row);
            }
        }

        if (game != null && game.getPreviousShortestPath() != null) {
            for (Node node : game.getPreviousShortestPath()) {
                Rectangle pathPart = new Rectangle(cellSize, cellSize);
                pathPart.setFill(Color.web("#98c379"));
                pathPart.setStroke(Color.web("#3c4049"));
                gameGrid.add(pathPart, node.getX(), node.getY());
            }
        }

        if (game != null) {
            boolean isFirst = true;
            for (Node node : game.getSnake().getBody()) {
                Rectangle snakePart = new Rectangle(cellSize, cellSize);
                if (isFirst) {
                    snakePart.setFill(Color.web("#218c74"));
                    isFirst = false;
                } else {
                    snakePart.setFill(Color.web("#61dafb"));
                }
                snakePart.setStroke(Color.web("#282c34"));
                gameGrid.add(snakePart, node.getX(), node.getY());
            }

            Node foodPosition = game.getFood().getPosition();
            Rectangle food = new Rectangle(cellSize, cellSize);
            food.setFill(Color.web("#e06c75"));
            food.setStroke(Color.web("#282c34"));
            gameGrid.add(food, foodPosition.getX(), foodPosition.getY());
        }
    }

    public void handleKeyPress(KeyEvent event) {
        if (game != null) {
            switch (event.getCode()) {
                case UP:
                case W:
                    game.changeDirection(Direction.UP);
                    break;
                case DOWN:
                case S:
                    game.changeDirection(Direction.DOWN);
                    break;
                case LEFT:
                case A:
                    game.changeDirection(Direction.LEFT);
                    break;
                case RIGHT:
                case D:
                    game.changeDirection(Direction.RIGHT);
                    break;
            }
            int scoreIncrement = game.update();
            updateScore(scoreIncrement);
            updateMoves(game.getMoves());
            updateLength(game.getSnake().getBody().size());
            if (game.isGameOver()) {
                showGameOver();
                game.reset();
                score = 0;
                updateScore(0);
            }
            drawGame();
        }
    }

    private void showGameOver() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Game Over");
        alert.setHeaderText(null);
        alert.setContentText("Has perdido el juego. Tu puntuación final es: " + score);
        alert.showAndWait();
    }
}