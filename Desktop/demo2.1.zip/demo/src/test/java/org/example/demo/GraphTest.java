package org.example.demo;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class GraphTest {

    @Test
    public void testDijkstraGraphList() {
        Graph graph = new GraphList();
        initializeGraph(graph);
        List<Node> path = graph.dijkstra(new Node(0, 0), new Node(4, 4));
        // Verificar que el camino más corto tiene la longitud correcta
        assertEquals(9, path.size());
    }

    @Test
    public void testDijkstraGraphMatrix() {
        Graph graph = new GraphMatrix(25);
        initializeGraph(graph);
        List<Node> path = graph.dijkstra(new Node(0, 0), new Node(4, 4));
        // Verificar que el camino más corto tiene la longitud correcta
        assertEquals(9, path.size());
    }

    @Test
    public void testBFSGraphList() {
        Graph graph = new GraphList();
        initializeGraph(graph);
        List<Node> path = graph.bfs(new Node(0, 0), new Node(4, 4));
        // Verificar que el camino más corto tiene la longitud correcta
        assertEquals(9, path.size());
    }

    @Test
    public void testBFSGraphMatrix() {
        Graph graph = new GraphMatrix(25);
        initializeGraph(graph);
        List<Node> path = graph.bfs(new Node(0, 0), new Node(4, 4));
        // Verificar que el camino más corto tiene la longitud correcta
        assertEquals(9, path.size());
    }

    private void initializeGraph(Graph graph) {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                graph.addNode(new Node(i, j));
            }
        }
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                Node node = new Node(i, j);
                if (i > 0) graph.addEdge(node, new Node(i - 1, j));
                if (i < 4) graph.addEdge(node, new Node(i + 1, j));
                if (j > 0) graph.addEdge(node, new Node(i, j - 1));
                if (j < 4) graph.addEdge(node, new Node(i, j + 1));
            }
        }
    }
}