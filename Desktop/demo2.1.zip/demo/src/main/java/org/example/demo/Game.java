package org.example.demo;

import java.util.List;
import java.util.Random;

public class Game {
    private Graph graph;
    private Snake snake;
    private Food food;
    private int score;
    private int rows = 20; // Número de filas del tablero
    private int cols = 20; // Número de columnas del tablero
    private int moves;     // Contador de movimientos
    private boolean gameOver;
    private List<Node> previousShortestPath; // Camino más corto anterior
    private List<Node> currentShortestPath;  // Camino más corto actual

    public Game(Graph graph) {
        this.graph = graph;
        initializeGame();
    }

    private void initializeGame() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                graph.addNode(new Node(i, j));
            }
        }
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                Node node = new Node(i, j);
                if (i > 0) graph.addEdge(node, new Node(i - 1, j));
                if (i < rows - 1) graph.addEdge(node, new Node(i + 1, j));
                if (j > 0) graph.addEdge(node, new Node(i, j - 1));
                if (j < cols - 1) graph.addEdge(node, new Node(i, j + 1));
            }
        }
        snake = new Snake(new Node(rows / 2, cols / 2));
        placeFood();
        score = 0;
        moves = 0;
        gameOver = false;
        previousShortestPath = null;
        currentShortestPath = null;
    }

    private void placeFood() {
        Random random = new Random();
        Node position;
        do {
            position = new Node(random.nextInt(rows), random.nextInt(cols));
        } while (snake.getBody().contains(position));
        food = new Food(position);
        // Calcular el nuevo camino más corto y guardar el anterior
        previousShortestPath = currentShortestPath;
        currentShortestPath = graph.dijkstra(snake.getBody().getFirst(), food.getPosition());
    }

    public Snake getSnake() {
        return snake;
    }

    public Food getFood() {
        return food;
    }

    public int getScore() {
        return score;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public int getMoves() {
        return moves;
    }

    public List<Node> getPreviousShortestPath() {
        return previousShortestPath;
    }

    public int update() {
        if (gameOver) {
            return 0;
        }

        Node head = snake.getBody().getFirst();
        Node nextPosition = new Node(
                head.getX() + snake.getDirection().getX(),
                head.getY() + snake.getDirection().getY()
        );

        if (CollisionDetection.detectCollision(snake, nextPosition) || isOutOfBounds(nextPosition)) {
            gameOver = true;
            return 0;
        } else {
            moves++;
            if (nextPosition.equals(food.getPosition())) {
                snake.grow();
                int scoreIncrement = calculateScore(nextPosition);
                score += scoreIncrement;
                placeFood();
                moves = 0;  // Resetear el contador de movimientos después de comer
                return scoreIncrement;
            } else {
                snake.move();

                int penalty = calculatePenalty(nextPosition);
                score -= penalty;
                return 0;
            }
        }
    }

    private boolean isOutOfBounds(Node position) {
        return position.getX() < 0 || position.getX() >= rows || position.getY() < 0 || position.getY() >= cols;
    }

    private int calculateScore(Node nextPosition) {
        List<Node> path = graph.dijkstra(snake.getBody().getFirst(), food.getPosition());
        int minPathLength = path.size();
        int penalty = moves - (minPathLength - 1);
        return Math.max(0, 10 - penalty);
    }

    private int calculatePenalty(Node nextPosition) {
        List<Node> path = graph.dijkstra(snake.getBody().getFirst(), food.getPosition());
        int minPathLength = path.size();
        if (path.contains(nextPosition) && path.indexOf(nextPosition) == 1) {
            return 0;
        }
        return 1;
    }

    public void changeDirection(Direction newDirection) {
        snake.changeDirection(newDirection);
    }

    public void reset() {
        initializeGame();
    }
}