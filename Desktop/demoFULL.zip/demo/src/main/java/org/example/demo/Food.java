package org.example.demo;

public class Food {
    private Node position;

    public Food(Node position) {
        this.position = position;
    }

    public Node getPosition() {
        return position;
    }

    public void setPosition(Node position) {
        this.position = position;
    }
}
