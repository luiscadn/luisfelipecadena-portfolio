package org.example.demo;

import java.util.List;

public interface Graph {
    void addNode(Node node);
    void addEdge(Node node1, Node node2);
    List<Node> getAdjNodes(Node node);
    List<Node> dijkstra(Node start, Node end);
    List<Node> bfs(Node start, Node end);
}

