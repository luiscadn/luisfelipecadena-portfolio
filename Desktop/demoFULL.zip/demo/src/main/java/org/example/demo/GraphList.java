package org.example.demo;

import java.util.*;

public class GraphList implements Graph {
    private final Map<Node, List<Node>> adjNodes;

    public GraphList() {
        this.adjNodes = new HashMap<>();
    }

    @Override
    public void addNode(Node node) {
        adjNodes.putIfAbsent(node, new ArrayList<>());
    }

    @Override
    public void addEdge(Node node1, Node node2) {
        adjNodes.get(node1).add(node2);
        adjNodes.get(node2).add(node1); // Assuming undirected graph
    }

    @Override
    public List<Node> getAdjNodes(Node node) {
        return adjNodes.get(node);
    }

    @Override
    public List<Node> dijkstra(Node start, Node end) {
        Map<Node, Node> prev = new HashMap<>();
        Map<Node, Integer> distances = new HashMap<>();
        PriorityQueue<Node> nodes = new PriorityQueue<>(Comparator.comparingInt(distances::get));

        for (Node node : adjNodes.keySet()) {
            if (node.equals(start)) {
                distances.put(node, 0);
            } else {
                distances.put(node, Integer.MAX_VALUE);
            }
            nodes.add(node);
        }

        while (!nodes.isEmpty()) {
            Node smallest = nodes.poll();
            if (smallest.equals(end)) {
                List<Node> path = new ArrayList<>();
                while (prev.containsKey(smallest)) {
                    path.add(smallest);
                    smallest = prev.get(smallest);
                }
                path.add(start);
                Collections.reverse(path);
                return path;
            }

            if (distances.get(smallest) == Integer.MAX_VALUE) {
                break;
            }

            for (Node neighbor : adjNodes.get(smallest)) {
                int alt = distances.get(smallest) + 1;
                if (alt < distances.get(neighbor)) {
                    distances.put(neighbor, alt);
                    prev.put(neighbor, smallest);
                    nodes.add(neighbor);
                }
            }
        }

        return new ArrayList<>();
    }

    @Override
    public List<Node> bfs(Node start, Node end) {
        Queue<Node> queue = new LinkedList<>();
        Map<Node, Node> prev = new HashMap<>();
        Set<Node> visited = new HashSet<>();
        queue.add(start);
        visited.add(start);

        while (!queue.isEmpty()) {
            Node node = queue.poll();
            if (node.equals(end)) {
                List<Node> path = new ArrayList<>();
                while (prev.containsKey(node)) {
                    path.add(node);
                    node = prev.get(node);
                }
                path.add(start);
                Collections.reverse(path);
                return path;
            }

            for (Node neighbor : adjNodes.get(node)) {
                if (!visited.contains(neighbor)) {
                    queue.add(neighbor);
                    visited.add(neighbor);
                    prev.put(neighbor, node);
                }
            }
        }

        return new ArrayList<>();
    }
}