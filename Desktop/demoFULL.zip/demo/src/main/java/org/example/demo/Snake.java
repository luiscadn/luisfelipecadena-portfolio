package org.example.demo;

import java.util.LinkedList;
import java.util.List;

public class Snake {
    private LinkedList<Node> body;
    private Direction direction;

    public Snake(Node initialPosition) {
        body = new LinkedList<>();
        body.add(initialPosition);
        direction = Direction.RIGHT;
    }

    public List<Node> getBody() {
        return body;
    }

    public Direction getDirection() {
        return direction;
    }

    public void move() {
        Node head = body.getFirst();
        Node newHead = new Node(head.getX() + direction.getX(), head.getY() + direction.getY());
        body.addFirst(newHead);
        body.removeLast();
    }

    public void grow() {
        Node head = body.getFirst();
        Node newHead = new Node(head.getX() + direction.getX(), head.getY() + direction.getY());
        body.addFirst(newHead);
    }

    public void changeDirection(Direction newDirection) {
        if (direction.getX() + newDirection.getX() != 0 || direction.getY() + newDirection.getY() != 0) {
            direction = newDirection;
        }
    }
}
