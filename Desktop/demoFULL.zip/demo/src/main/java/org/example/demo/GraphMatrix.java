package org.example.demo;

import java.util.*;

public class GraphMatrix implements Graph {
    private final int size;
    private final boolean[][] adjMatrix;
    private final Map<Node, Integer> nodeIndex;
    private final List<Node> indexNode;

    public GraphMatrix(int size) {
        this.size = size;
        this.adjMatrix = new boolean[size][size];
        this.nodeIndex = new HashMap<>();
        this.indexNode = new ArrayList<>(size);
    }

    @Override
    public void addNode(Node node) {
        int index = indexNode.size();
        nodeIndex.put(node, index);
        indexNode.add(node);
    }

    @Override
    public void addEdge(Node node1, Node node2) {
        int index1 = nodeIndex.get(node1);
        int index2 = nodeIndex.get(node2);
        adjMatrix[index1][index2] = true;
        adjMatrix[index2][index1] = true; // Assuming undirected graph
    }

    @Override
    public List<Node> getAdjNodes(Node node) {
        int index = nodeIndex.get(node);
        List<Node> adjNodes = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            if (adjMatrix[index][i]) {
                adjNodes.add(indexNode.get(i));
            }
        }
        return adjNodes;
    }

    @Override
    public List<Node> dijkstra(Node start, Node end) {
        Map<Node, Node> prev = new HashMap<>();
        Map<Node, Integer> distances = new HashMap<>();
        PriorityQueue<Node> nodes = new PriorityQueue<>(Comparator.comparingInt(distances::get));

        for (Node node : nodeIndex.keySet()) {
            if (node.equals(start)) {
                distances.put(node, 0);
            } else {
                distances.put(node, Integer.MAX_VALUE);
            }
            nodes.add(node);
        }

        while (!nodes.isEmpty()) {
            Node smallest = nodes.poll();
            if (smallest.equals(end)) {
                List<Node> path = new ArrayList<>();
                while (prev.containsKey(smallest)) {
                    path.add(smallest);
                    smallest = prev.get(smallest);
                }
                path.add(start);
                Collections.reverse(path);
                return path;
            }

            if (distances.get(smallest) == Integer.MAX_VALUE) {
                break;
            }

            for (Node neighbor : getAdjNodes(smallest)) {
                int alt = distances.get(smallest) + 1;
                if (alt < distances.get(neighbor)) {
                    distances.put(neighbor, alt);
                    prev.put(neighbor, smallest);
                    // Remove and reinsert to update the priority queue
                    nodes.remove(neighbor);
                    nodes.add(neighbor);
                }
            }
        }

        return new ArrayList<>();
    }

    @Override
    public List<Node> bfs(Node start, Node end) {
        Queue<Node> queue = new LinkedList<>();
        Map<Node, Node> prev = new HashMap<>();
        Set<Node> visited = new HashSet<>();
        queue.add(start);
        visited.add(start);

        while (!queue.isEmpty()) {
            Node node = queue.poll();
            if (node.equals(end)) {
                List<Node> path = new ArrayList<>();
                while (prev.containsKey(node)) {
                    path.add(node);
                    node = prev.get(node);
                }
                path.add(start);
                Collections.reverse(path);
                return path;
            }

            for (Node neighbor : getAdjNodes(node)) {
                if (!visited.contains(neighbor)) {
                    queue.add(neighbor);
                    visited.add(neighbor);
                    prev.put(neighbor, node);
                }
            }
        }

        return new ArrayList<>();
    }
}