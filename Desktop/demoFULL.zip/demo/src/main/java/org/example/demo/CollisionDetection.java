
package org.example.demo;

public class CollisionDetection {
    public static boolean detectCollision(Snake snake, Node nextPosition) {
        for (Node segment : snake.getBody()) {
            if (segment.equals(nextPosition)) {
                return true;
            }
        }
        if (nextPosition.getX() < 0 || nextPosition.getX() >= 20 || nextPosition.getY() < 0 || nextPosition.getY() >= 20) {
            return true;
        }
        return false;
    }
}
